export const DOCUMENT_TYPES = [
  "Passport Size Photo",
  "Passport PDF",
  "10th/12th Certificates",
  "Degree & Transcripts",
  "APS Certificate",
  "Language Certificate",
  "LOR - Company",
  "LOR - Professor",
  "SOP Questionnaire",
  "Research Work",
  "Project Work",
  "Internship Letters",
  "Extra Curriculars",
  "Entrance Exam Certificates",
  "Bachelors / Masters Course Modules",
  "Grading System PDF",
  "Other Documents"
];
