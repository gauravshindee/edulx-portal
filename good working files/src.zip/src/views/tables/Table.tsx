import { ProductTable } from "src/components/tables/ProductTable"


const Table = () => {
  return (
     <>
     <ProductTable/>
     </>
  )
}

export default Table